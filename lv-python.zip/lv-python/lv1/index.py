x = 8
valueFloat = 8.2
text = "Hello,World!"

my_list = ["Hello", 2, 3.14, True]

my_tuple = ("Hello", 2, 3.14, True)

my_dict = {}
my_dict["country"] = "Russia"

s = set()
s = ("hi", "bye")

print("Int = ", x)
print("Float = ", valueFloat)
print("String", text)
print("List = ", my_list)
print("Tuple = ", my_tuple)
print("Dictionary = ", my_dict)
print("Set = ", s)